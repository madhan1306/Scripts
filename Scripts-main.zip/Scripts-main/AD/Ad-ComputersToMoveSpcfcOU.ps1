﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Path to the text file (one computer per line)
# Entries can be either:
#   - Computer SamAccountName (without $) e.g. PC01
#   - DistinguishedName e.g. CN=PC01,OU=OldOU,DC=domain,DC=com
$ComputerList = Get-Content "C:\Users\venkatesh.k\Downloads\AD-To-InStock.txt"

# Destination OU distinguished name
$TargetOU = "OU=IT_Stock,DC=STI,DC=COM"

foreach ($Computer in $ComputerList) {
    try {
        # Check if it's a DN or a SamAccountName
        if ($Computer -match "^CN=.*?,DC=.*") {
            # Already a DistinguishedName
            $ADComputer = Get-ADComputer -Identity $Computer -ErrorAction Stop
        }
        else {
            # Assume it's a computer name (SamAccountName without $)
            $ADComputer = Get-ADComputer -Identity $Computer -ErrorAction Stop
        }

        # Move computer only if it's not already in the target OU
        if ($ADComputer.DistinguishedName -notlike "*$TargetOU") {
            Move-ADObject -Identity $ADComputer.DistinguishedName -TargetPath $TargetOU -ErrorAction Stop
            Write-Host "Moved computer $Computer to $TargetOU" -ForegroundColor Green
        }
        else {
            Write-Host "Computer $Computer is already in $TargetOU, skipping." -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "Failed to process $Computer. Error: $_" -ForegroundColor Red
    }
}
