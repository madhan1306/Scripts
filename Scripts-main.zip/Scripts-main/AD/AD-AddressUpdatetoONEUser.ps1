﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Define the user's SamAccountName
$samAccountName = "ksccconsole"

# Define the new address details
$streetAddress = "Sun Technology Integrators Pvt. Ltd,
No.496, 1st stage,4th Block, HBR Layout, 
Bangalore 560043"
$city = "Bangalore"
$state = "Karnataka"
$postalCode = "560043"


# Update the user's address attributes
try {
    # Update StreetAddress
    Set-ADUser -Identity $samAccountName -StreetAddress $streetAddress
    Write-Host "Street address updated successfully."

    # Update City
    Set-ADUser -Identity $samAccountName -City $city
    Write-Host "City updated successfully."

    # Update State
    Set-ADUser -Identity $samAccountName -State $state
    Write-Host "State updated successfully."

    # Update PostalCode
    Set-ADUser -Identity $samAccountName -PostalCode $postalCode
    Write-Host "Postal code updated successfully."

    # Update Country
    Set-ADUser -Identity $samAccountName -Country $country
    Write-Host "Country updated successfully."
} catch {
    Write-Host "Failed to update address attribute: $_"
}

# Confirm the update by retrieving the updated attributes
$user = Get-ADUser -Identity $samAccountName -Properties StreetAddress, City, State, PostalCode, Country
$user | Select-Object SamAccountName, StreetAddress, City, State, PostalCode, Country
