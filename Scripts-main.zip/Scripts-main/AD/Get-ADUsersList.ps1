Import-Module ActiveDirectory

Get-ADUser -Filter * -Properties DisplayName, UserPrincipalName, EmailAddress, DistinguishedName, Office, Department | 
Select-Object Name, DisplayName, UserPrincipalName, EmailAddress, Office, Department, @{Name="OU";Expression={$_.DistinguishedName -split "," | Where-Object {$_ -match "OU="} }} |
Export-Csv "C:\Users\venkatesh.k\Downloads\ADUserList.csv" -NoTypeInformation -Encoding UTF8