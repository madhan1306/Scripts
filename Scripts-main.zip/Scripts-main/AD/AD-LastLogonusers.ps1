﻿# Import Active Directory module
Import-Module ActiveDirectory

# Get all users from Active Directory
$users = Get-ADUser -Filter * -Properties SamAccountName, LastLogonTimestamp

# Define the output CSV file
$outputFile = "c:\LastLogonReport.csv"

# Create an array to store results
$results = @()

# Loop through each user and gather last logon information
foreach ($user in $users) {
    $lastLogon = [DateTime]::FromFileTime($user.LastLogonTimestamp)
    $result = [PSCustomObject]@{
        Username = $user.SamAccountName
        LastLogon = $lastLogon
    }
    $results += $result
}

# Export results to CSV
$results | Export-Csv -Path $outputFile -NoTypeInformation

Write-Host "Last logon information exported to $outputFile"
