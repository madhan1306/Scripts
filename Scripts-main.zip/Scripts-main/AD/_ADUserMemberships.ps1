# Import Active Directory module
Import-Module ActiveDirectory

# Set the output file path
$outputFile = "C:\Users\venkatesh.k\Downloads\ADUserMemberships.csv"

# Get all user accounts from Active Directory
$users = Get-ADUser -Filter * -Properties MemberOf, Department, DistinguishedName

# Initialize an array to store user membership data
$userMemberships = @()

# Loop through each user and retrieve group memberships
foreach ($user in $users) {
    # Get group names
    $groupNames = @()
    if ($user.MemberOf) {
        $groupNames = $user.MemberOf | Get-ADGroup | Select-Object -ExpandProperty Name
    }

    # Extract OU from DN
    $OU = ($user.DistinguishedName -split ',') -match '^OU=' -replace '^OU='
    $OUPath = ($OU -join '/')  # Join for better readability

    $userMembership = [PSCustomObject]@{
        User             = $user.SamAccountName
        Department       = $user.Department
        OUName           = $OUPath
        GroupMemberships = $groupNames -join ', '
    }

    $userMemberships += $userMembership
}

# Export the user memberships to a CSV file
$userMemberships | Export-Csv -Path $outputFile -NoTypeInformation

Write-Host "User memberships exported to $outputFile"
