﻿# Import Active Directory module
Import-Module ActiveDirectory

# Path to the text file containing usernames (one username per line)
$usernamesFile = "C:\Users\venkatesh.k\Downloads\AD\ADUsernames.txt"

# Read the usernames from the text file
$usernames = Get-Content $usernamesFile

# Loop through each username and clear "Password Never Expires" attribute
foreach ($username in $usernames) {
    # Check if the user exists in Active Directory
    $user = Get-ADUser -Filter { SamAccountName -eq $username }
    if ($user) {
        # Clear "Password Never Expires" attribute for the user
        Set-ADUser -Identity $user -PasswordNeverExpires $false
        Write-Host "Cleared 'Password Never Expires' for user: $username"
    } else {
        Write-Host "User not found: $username. Skipping attribute update."
    }
}
