### Step 1: Define variables ###
$domain = "STI"
$gmsaName = "schedtask"
$groupName = "AD-gMSA-Access"
$computerName = "STIPL-SRV-DFS1"  # Replace with actual computer name or use $env:COMPUTERNAME
$groupOU = "OU=Managed Service Accounts,DC=sti,DC=com"  # ✅ Using your chosen OU

### Step 2: Create the group in specified OU if it doesn't exist ###
if (-not (Get-ADGroup -Filter "Name -eq '$groupName'")) {
    New-ADGroup -Name $groupName -GroupScope Global -Path $groupOU
    Write-Host "Created group: $groupName in $groupOU"
} else {
    Write-Host "Group $groupName already exists"
}

### Step 3: Add computer to the group ###
Add-ADGroupMember -Identity $groupName -Members "$computerName`$"
Write-Host "Added $computerName to $groupName"

### Step 4: Delete old user account with same name (if exists) ###
if (Get-ADUser -Filter "SamAccountName -eq '$gmsaName'" -ErrorAction SilentlyContinue) {
    Remove-ADUser -Identity $gmsaName -Confirm:$false
    Write-Host "Deleted existing user account: $gmsaName"
}

Start-Sleep -Seconds 10  # Optional wait for replication

### Step 5: Create the gMSA ###
if (-not (Get-ADServiceAccount -Identity $gmsaName -ErrorAction SilentlyContinue)) {
    New-ADServiceAccount -Name $gmsaName -DNSHostName "$domain.com" -PrincipalsAllowedToRetrieveManagedPassword $groupName
    Write-Host "Created gMSA: $gmsaName"
} else {
    Write-Host "gMSA $gmsaName already exists"
}

### Step 6: Install the gMSA on local machine ###
Install-ADServiceAccount -Identity $gmsaName
if (Test-ADServiceAccount -Identity $gmsaName) {
    Write-Host "✅ gMSA $gmsaName is installed and ready on $computerName"
} else {
    Write-Host "❌ Failed to install or test gMSA. Check group membership and replication." -ForegroundColor Red
}
