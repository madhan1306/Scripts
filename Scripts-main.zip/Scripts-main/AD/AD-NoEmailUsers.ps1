﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Retrieve all AD users and filter for those who are enabled and do not have an email address.
Get-ADUser -Filter "Enabled -eq 'True'" -Properties EmailAddress | Where-Object { $_.EmailAddress -eq $null -or $_.EmailAddress -eq "" } | Select-Object Name, SamAccountName, EmailAddress | Export-Csv "C:\NoEmailUsers.csv" -NoTypeInformation
