Import-Module ActiveDirectory
$DaysAhead = 7
$Today = (Get-Date)
$Users = Get-ADUser -Filter * -Properties "msDS-UserPasswordExpiryTimeComputed" |
Where-Object { $_."msDS-UserPasswordExpiryTimeComputed" -ne $null } |
Select-Object Name, SamAccountName,
@{Name="PasswordExpiryDate";Expression={[datetime]::FromFileTime($_."msDS-UserPasswordExpiryTimeComputed")}}
$Users | Where-Object { $_.PasswordExpiryDate -lt $Today.AddDays($DaysAhead) } |
Export-Csv "C:\ADReports\Reports\PasswordExpiry_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation