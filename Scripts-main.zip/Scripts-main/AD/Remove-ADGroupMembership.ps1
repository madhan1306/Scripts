# Import the Active Directory module
Import-Module ActiveDirectory

# Define the OU path
$OU = "OU=Disabled Users,DC=STI,DC=COM"

# Get all disabled users in the specified OU
$DisabledUsers = Get-ADUser -Filter {Enabled -eq $false} -SearchBase $OU -SearchScope Subtree

foreach ($User in $DisabledUsers) {
    # Get the user's group memberships
    $Groups = Get-ADUser $User -Property MemberOf | Select-Object -ExpandProperty MemberOf

    foreach ($Group in $Groups) {
        # Remove the user from each group
        Remove-ADGroupMember -Identity $Group -Members $User -Confirm:$false
    }
}

Write-Host "All disabled users in $OU have been removed from their group memberships."
