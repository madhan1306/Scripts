﻿$OUpath = 'OU=AccountsComputers,OU=IDC01,DC=STI,DC=COM'
$ExportPath = 'c:\OU-AD.csv'
Get-ADUser -Filter * -SearchBase $OUpath | Select-object
DistinguishedName,Name,UserPrincipalName | Export-Csv -NoType $ExportPath