$Roles = Get-ADDomain | Select-Object InfrastructureMaster, RIDMaster, PDCEmulator
$ForestRoles = Get-ADForest | Select-Object SchemaMaster, DomainNamingMaster
$OutFile = "C:\ADReports\Reports\FSMORoles_$(Get-Date -Format yyyyMMdd).txt"
$Roles | Out-File $OutFile
$ForestRoles | Out-File $OutFile -Append