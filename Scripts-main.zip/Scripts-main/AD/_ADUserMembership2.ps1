﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Get the group and its members, format the output, and export it to a CSV file
Get-ADGroup -Identity "Restrict_NW_Group" -Properties Members | 
    Select-Object Name, @{Name='Members'; Expression={($_.Members | ForEach-Object { (Get-ADObject $_).Name }) -join "," }} | 
    Sort-Object -Property Name | 
    Export-Csv -Path "C:\ADuser-MemberOf.csv" -NoTypeInformation -Encoding UTF8
