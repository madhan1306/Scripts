Import-Module GroupPolicy
$CutOff = (Get-Date).AddDays(-7)
$GPOs = Get-GPO -All | Where-Object { $_.ModificationTime -ge $CutOff }
$GPOs | Select DisplayName, ModificationTime |
Export-Csv "C:\ADReports\Reports\RecentGPOs_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation