﻿# Import the Active Directory module if it's not already loaded
Import-Module ActiveDirectory

# Set the output file path
$outputFile = "C:\Users\venkatesh.k\Downloads\AdUser-GroupMemberships.csv"

# Get all users in the domain, including the 'Enabled' property
$users = Get-ADUser -Filter * -Properties SamAccountName, DisplayName, EmailAddress, MemberOf, Enabled

# Initialize an array to store the user data
$userData = @()

foreach ($user in $users) {
    # Get user's group memberships
    $userGroups = ($user.MemberOf | ForEach-Object { (Get-ADGroup -Identity $_).Name }) -join "; "
    
    # Create a custom object with the user properties and groups
    $userData += [PSCustomObject]@{
        SamAccountName = $user.SamAccountName
        DisplayName    = $user.DisplayName
        Enabled        = $user.Enabled -eq $true
        Groups         = $userGroups
    }
}

# Export the user data to a CSV file
$userData | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8

Write-Output "Export completed. User properties, including status, have been saved to $outputFile"
