﻿# Define the directory to search and the minimum file size (in GB)
$directoryToSearch = "C:\Users\venkatesh.k"
$minimumSizeGB = 1  # Adjust this value to the desired size in gigabytes

 

# Convert minimum size to bytes
$minimumSizeBytes = $minimumSizeGB * 1GB

 

# Get the list of files larger than the minimum size in the specified directory and subdirectories
$bigFiles = Get-ChildItem -Path $directoryToSearch -Recurse | Where-Object { $_.Length -gt $minimumSizeBytes }

 

# Select and calculate the size in GB for each big file
$bigFilesData = $bigFiles | Select-Object FullName, @{Name="Size(GB)"; Expression={$_.Length / 1GB}}

 

# Specify the path for the output CSV file
$outputCSV = "C:\Users\venkatesh.k\Downloads\BigFilesReport.csv"

 

# Export the big files data to a CSV file
$bigFilesData | Export-Csv -Path $outputCSV -NoTypeInformation

 

Write-Host "Big files report exported to $outputCSV"