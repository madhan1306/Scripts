﻿# Define the DN of the group you want to query
$groupDN = "CN=WPatch_Test,OU=IT Infra,OU=Custom User Groups,DC=STI,DC=COM"

# Set up the LDAP filter to query members of the group
$filter = "(&(objectCategory=computer)(memberOf=$groupDN))"

# Perform the LDAP query
$searcher = New-Object DirectoryServices.DirectorySearcher([ADSI]"")
$searcher.Filter = $filter
$searcher.PageSize = 1000  # You can adjust the page size as needed

# Retrieve the results
$results = $searcher.FindAll()

# Create an array to store the results
$computerList = @()

# Iterate through the results and add them to the array
foreach ($result in $results) {
    $computerName = $result.Properties["name"][0]
    $computerList += New-Object PSObject -Property @{
        "ComputerName" = $computerName
    }
}

# Export the results to a CSV file
$computerList | Export-Csv -Path "C:\File.csv" -NoTypeInformation
