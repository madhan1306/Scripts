﻿#-----------------CSV Format ---------------
#Username,FirstName,LastName,DisplayName,LogonName,Password,EmailAddress,Description,Office,Title,Department,Group,OU,Company,Street,City,State,PostalCode,Country,WebPage
#jdoe,John,Doe,John Doe,jdoe@sti.com,P@ssw0rd123,jdoe@sti.com,Sales Executive,New York,Sales Rep,Sales,Sales_Team,"OU=Sales,OU=Users,DC=sti,DC=com",YourCompany,123 Main St,Mumbai,Maharashtra,400001,IN,www.company.com

# Add bulk users in Active Directory

Import-Module ActiveDirectory

$UserList = Import-Csv -Path "C:\Scripts\Users.csv"

foreach ($user in $UserList) {
    try {
        $securePassword = ConvertTo-SecureString $user.Password -AsPlainText -Force

        New-ADUser `
            -SamAccountName $user.Username `
            -UserPrincipalName $user.LogonName `
            -Name $user.DisplayName `
            -GivenName $user.FirstName `
            -Surname $user.LastName `
            -DisplayName $user.DisplayName `
            -EmailAddress $user.EmailAddress `
            -Description $user.Description `
            -Office $user.Office `
            -Title $user.Title `
            -Department $user.Department `
            -Company $user.Company `
            -StreetAddress $user.Street `
            -City $user.City `
            -State $user.State `
            -PostalCode $user.PostalCode `
            -Country $user.Country `
            -HomePage $user.WebPage `
            -AccountPassword $securePassword `
            -Enabled $true `
            -Path $user.OU `
            -PassThru | Out-Null

        Write-Host "Created new user: $($user.Username)" -ForegroundColor Green

        if ($user.Group) {
            if (Get-ADGroup -Identity $user.Group -ErrorAction SilentlyContinue) {
                Add-ADGroupMember -Identity $user.Group -Members $user.Username
                Write-Host "Added $($user.Username) to group: $($user.Group)" -ForegroundColor Magenta
            } else {
                Write-Warning "Group not found: $($user.Group)"
            }
        }

    } catch {
        Write-Warning "Error creating user $($user.Username): $_"
    }
}
