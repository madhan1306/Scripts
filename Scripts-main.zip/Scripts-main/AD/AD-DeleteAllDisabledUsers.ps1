﻿Import-Module ActiveDirectory

# Define log file paths
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$disabledLog = "C:\DisabledUsers_$timestamp.csv"
$deletionLog = "C:\DeletedUsers_$timestamp.csv"
$groupMembershipLog = "C:\GroupMemberships_$timestamp.csv"

# Get all disabled users
$disabledUsers = Get-ADUser -Filter {Enabled -eq $false} -Properties MemberOf, SamAccountName, DistinguishedName

# Initialize log arrays
$disabledLogList = @()
$deletedLogList = @()
$groupMembershipLogList = @()

foreach ($user in $disabledUsers) {
    # Export disabled user info
    $disabledLogList += [PSCustomObject]@{
        SamAccountName = $user.SamAccountName
        DistinguishedName = $user.DistinguishedName
    }

    # Log group memberships before removal
    foreach ($groupDN in $user.MemberOf) {
        $groupMembershipLogList += [PSCustomObject]@{
            User              = $user.SamAccountName
            GroupDistinguishedName = $groupDN
        }

        # Remove from group
        Remove-ADGroupMember -Identity $groupDN -Members $user -Confirm:$false -ErrorAction SilentlyContinue
    }

    # Delete user
    try {
        Remove-ADUser -Identity $user -Confirm:$false
        $deletedLogList += [PSCustomObject]@{
            SamAccountName = $user.SamAccountName
            Deleted        = "Yes"
        }
    } catch {
        $deletedLogList += [PSCustomObject]@{
            SamAccountName = $user.SamAccountName
            Deleted        = "Failed: $_"
        }
    }
}

# Export logs
$disabledLogList | Export-Csv -Path $disabledLog -NoTypeInformation
$deletedLogList | Export-Csv -Path $deletionLog -NoTypeInformation
$groupMembershipLogList | Export-Csv -Path $groupMembershipLog -NoTypeInformation

Write-Output "✅ Operation completed. Logs saved to path"
