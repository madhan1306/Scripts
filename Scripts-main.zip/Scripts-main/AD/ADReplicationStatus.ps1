$Report = Get-ADReplicationFailure -Scope Site -Target * |
    Select Server, FirstFailureTime, FailureCount, FailureType, Partner
$Out = "C:\ADReports\Reports\ADReplicationStatus_$(Get-Date -Format yyyyMMdd).csv"
$Report | Export-Csv $Out -NoTypeInformation