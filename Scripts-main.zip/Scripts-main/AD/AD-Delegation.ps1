﻿# Define variables
$OUPath = "OU=SUN1,DC=STI,DC=COM" # Replace with the desired OU

# $DelegateUser = "UserToDelegate" # Replace with the username of the user to delegate permissions
$DelegateGroup = "Desktop_Admin" # Replace with the name of a security group to hold the delegated users

# Create a new security group for delegated joiners
# New-ADGroup -Name $DelegateGroup -GroupScope Global -Path $OUPath -Description "Delegated Joiners Group"

# Delegate permissions to join and disjoin computers to/from the domain
# $DelegatedTasks = "CreateChild,DeleteChild"
$DelegatedTasks = "CreateChild,DeleteChild"
$DelegatedRights = "Computer"

# Grant the delegation
$DelegationRule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
    $DelegateUser,
    $DelegatedTasks,
    [System.Security.AccessControl.AccessControlType]::Allow,
    [System.Guid]"00000000-0000-0000-0000-000000000000"
)

$OU = Get-ADOrganizationalUnit -Filter { DistinguishedName -eq $OUPath }
$OU | Set-ADACL -Add @($DelegationRule)

# Add the user to the delegated group
Add-ADGroupMember -Identity $DelegateGroup -Members $DelegateUser