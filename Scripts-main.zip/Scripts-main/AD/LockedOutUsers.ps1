Search-ADAccount -LockedOut |
    Select Name, SamAccountName, DistinguishedName |
    Export-Csv "C:\ADReports\Reports\LockedOutUsers_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation