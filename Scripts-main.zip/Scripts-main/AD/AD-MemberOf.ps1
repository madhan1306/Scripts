Get-ADgroup -Filter * -SearchBase "DC=sti,DC=Com" -Properties members | select name, @{n=�Members�; e= { ( $_.members | % { 

(Get-ADObject $_).Name }) -join �,� }} | Sort-Object -Property Name |Export-csv -path C:\ADuser-MemberOf.csv -NoTypeInformation -Encoding UTF8