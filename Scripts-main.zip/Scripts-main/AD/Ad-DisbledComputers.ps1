﻿# Import Active Directory module
Import-Module ActiveDirectory

# Set the output file path
$outputFile = "C:\Users\venkatesh.k\Downloads\DisabledComputers60Days.csv"

# Calculate the date 60 days ago
$thresholdDate = (Get-Date).AddDays(-60)

# Get disabled computer accounts older than 60 days from Active Directory
$disabledComputers = Get-ADComputer -Filter {Enabled -eq $false -and LastLogonDate -lt $thresholdDate} -Properties LastLogonDate

# Select the properties to export and format the LastLogonDate
$computerData = $disabledComputers | Select-Object Name, DistinguishedName, @{Name="LastLogonDate"; Expression={$_.LastLogonDate.ToString("yyyy-MM-dd")}}

# Export the computer accounts to a CSV file
$computerData | Export-Csv -Path $outputFile -NoTypeInformation

Write-Host "Disabled computers older than 60 days exported to $outputFile"
