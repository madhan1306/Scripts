﻿# Path to your text file containing computer names (one per line) 
#$ComputerListPath = "C:\Users\venkatesh.k\Downloads\us-pc.txt"

# Destination OU
#$TargetOU = "OU=Desktops,OU=USOFF,DC=STI,DC=COM"

# Destination OU
#$TargetOU = "OU=US_Stock,OU=USOFF,DC=STI,DC=COM"



# Path to exclusion list
$ExcludeListPath = "C:\Users\venkatesh.k\Downloads\us-pc.txt"

# Source OU (where computers are currently located)
$SourceOU = "OU=Desktops,OU=USOFF,DC=STI,DC=COM"

# Destination OU
$TargetOU = "OU=US_Stock,OU=USOFF,DC=STI,DC=COM"

# Import Active Directory module
Import-Module ActiveDirectory

# Read exclusion list
$ExcludedComputers = Get-Content -Path $ExcludeListPath |
    ForEach-Object { $_.Trim().ToUpper() } |
    Where-Object { $_ -ne "" }

# Get computers from the source OU only
$SourceComputers = Get-ADComputer -SearchBase $SourceOU -SearchScope OneLevel -Filter * -Properties DistinguishedName

foreach ($Computer in $SourceComputers) {
    $ComputerName = $Computer.Name.ToUpper()

    if ($ExcludedComputers -contains $ComputerName) {
        Write-Host "Skipping excluded computer: $ComputerName" -ForegroundColor Yellow
    }
    else {
        try {
            Move-ADObject -Identity $Computer.DistinguishedName -TargetPath $TargetOU -ErrorAction Stop
            Write-Host "Moved $ComputerName to $TargetOU" -ForegroundColor Green
        }
        catch {
            Write-Warning ("Failed to move {0}: {1}" -f $ComputerName, $_.Exception.Message)
        }
    }
}
