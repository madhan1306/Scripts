# Import the Active Directory module
Import-Module ActiveDirectory

# Define the group name
$GroupName = "WPatch_Test"

# Path to the text file containing computer names (one per line)
$ComputerListFile = "C:\Users\venkatesh.k\Downloads\Computers.txt"

# Read the list of computers from the file
$Computers = Get-Content -Path $ComputerListFile

foreach ($ComputerName in $Computers) {
    # Check if the computer exists in the group
    $Computer = Get-ADComputer -Identity $ComputerName -ErrorAction SilentlyContinue
    if ($Computer) {
        Remove-ADGroupMember -Identity $GroupName -Members $Computer -Confirm:$false
        Write-Host "Removed $ComputerName from $GroupName."
    } else {
        Write-Host "$ComputerName not found in AD."
    }
}

Write-Host "All specified computers have been processed."
