﻿Import-Module ActiveDirectory

# Specify the OU distinguished name
$OU = "OU=Users,OU=IT_Support_Team,OU=SUN1,DC=STI,DC=COM"

# Specify the new department name
$NewDepartment = "IT SUPPORT"

# Get all users in the specified OU
Get-ADUser -Filter * -SearchBase $OU | ForEach-Object {
    # Update the department attribute for each user
    Set-ADUser -Identity $_ -Department $NewDepartment
    Write-Host "Updated department for user: $($_.SamAccountName)"
}

Write-Host "Department update completed."