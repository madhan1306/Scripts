# Import the Active Directory module
Import-Module ActiveDirectory

# Get a list of disabled computers
$disabledComputers = Get-ADComputer -Filter {Enabled -eq $false}

# Display the list of disabled computers
foreach ($computer in $disabledComputers) {
    Write-Host "Computer Name: $($computer.Name)"
}
