﻿# Import the Active Directory module (if not already loaded)
Import-Module ActiveDirectory

# Define the DN of the source OU where the disabled users are currently located
$sourceOU = "DC=STI,DC=com"

# Define the DN of the target OU where you want to move the disabled users
$targetOU = "OU=Disabled Users,DC=STI,DC=COM"

# Get a list of disabled user accounts in the source OU
$disabledUsers = Get-ADUser -Filter {Enabled -eq $false} -SearchBase $sourceOU

# Move the disabled users to the target OU
foreach ($user in $disabledUsers) {
    Move-ADObject -Identity $user.DistinguishedName -TargetPath $targetOU
}

