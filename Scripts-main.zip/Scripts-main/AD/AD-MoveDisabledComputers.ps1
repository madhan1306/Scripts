﻿# Import Active Directory module
Import-Module ActiveDirectory

# Set the distinguished name (DN) of the source OU containing the disabled computer accounts
$sourceOUDN = "DC=STI,DC=com"

# Set the distinguished name (DN) of the destination OU where you want to move the disabled computer accounts
$destinationOUDN = "OU=Disabled Computers,DC=sti,DC=com"

# Get the disabled computer accounts from the source OU
$disabledComputers = Search-ADAccount -AccountDisabled -ComputersOnly -SearchBase $sourceOUDN

# Move the disabled computer accounts to the destination OU
foreach ($computer in $disabledComputers) {
    Move-ADObject -Identity $computer.DistinguishedName -TargetPath $destinationOUDN
    Write-Host "Moved disabled computer '$($computer.Name)' to the destination OU."
}
