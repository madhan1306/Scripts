﻿# Import Active Directory module
Import-Module ActiveDirectory

# Set output CSV path
$outputFile = "C:\Logs\AdUser-GroupMemberships.csv"

# Get all users with specified properties
$users = Get-ADUser -Filter * -Properties SamAccountName, DisplayName, EmailAddress, MemberOf, Enabled

# Initialize array for user data
$userData = @()

foreach ($user in $users) {
    # Get group names, join by semicolon
    $userGroups = ($user.MemberOf | ForEach-Object { (Get-ADGroup -Identity $_).Name }) -join "; "

    # Create custom object for each user
    $userData += [PSCustomObject]@{
        SamAccountName = $user.SamAccountName
        DisplayName    = $user.DisplayName
        Enabled        = $user.Enabled -eq $true
        Groups         = $userGroups
    }
}

# Export to CSV
$userData | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8

Write-Output "Export completed. File saved at $outputFile"

# ----------- SMTP Email Settings ------------

# Replace these with your SMTP server details and credentials
$smtpServer = "suntechnologies-com.mail.protection.outlook.com"
$smtpPort = 25
$smtpUser = "notifications@suntechnologies.com"
$smtpPass = "4 8lquAn^cg*~XBd"

$from = "venkatesh.krishna@suntechnologies.com"
$to = "venkatesh.krishna@suntechnologies.com"
$subject = "ITInfra-Server | AD User Group Membership Export"
$body = "Hi,

Please find attached the latest Active Directory user group membership report.

File Save Path: S:\IT_Infrastructure\04_LOGs_&_REPORTS\2025\03_SERVER_REPORTS\USER GROUP MEMBERSHIP WEEKLY REPORT


Thanks,
Venkatesh Krishna
System Administrator
IT Department | Sun Technology Integrators Pvt Ltd"

# Create secure password
$securePass = ConvertTo-SecureString $smtpPass -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential ($smtpUser, $securePass)

# Send email with attachment
try {
    Send-MailMessage -From $from -To $to -Subject $subject -Body $body -SmtpServer $smtpServer -Port $smtpPort -UseSsl -Credential $cred -Attachments $outputFile
    Write-Output "Email sent successfully to $to"
}
catch {
    Write-Error "Failed to send email: $_"
}
