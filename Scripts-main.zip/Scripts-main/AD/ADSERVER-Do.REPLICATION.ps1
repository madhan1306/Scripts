﻿# Check if the script is running with administrative privileges
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Please run this script with administrative privileges."
    Exit
}

# Specify the target AD server(s) for replication
$targetServers = @("STIPL-SRV-ADC01", "STIPL-SRV-DC002", "STIPL-SRV-DCVM1", "STI-SRV-DC07")  # Replace with the actual server names

# Loop through the target servers and force replication
foreach ($server in $targetServers) {
    Write-Host "Forcing replication on $server..."
    Start-Process -FilePath "repadmin.exe" -ArgumentList "/syncall /APed $server" -Wait -NoNewWindow
}
