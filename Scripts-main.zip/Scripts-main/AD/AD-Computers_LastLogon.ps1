﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Define the output file path
$outputFile = "C:\Users\venkatesh.k\Downloads\AD_Computers_LastLogon.csv"

# Query Active Directory for computers
$computers = Get-ADComputer -Filter * -Properties Name, LastLogonDate, DistinguishedName, Enabled

# Create an array to store the results
$results = @()

# Loop through each computer and gather information
foreach ($computer in $computers) {
    $computerName = $computer.Name
    $lastLogon = $computer.LastLogonDate
    $ou = ($computer.DistinguishedName -split ",", 2)[1].Trim()
    $enabled = $computer.Enabled

    # Create a custom object with the desired properties
    $computerInfo = [PSCustomObject]@{
        "ComputerName" = $computerName
        "LastLogonDate" = $lastLogon
        "OU" = $ou
        "Enabled" = $enabled
    }

    # Add the object to the results array
    $results += $computerInfo
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputFile -NoTypeInformation

Write-Host "AD computer information exported to $outputFile"

 