$Out = "C:\ADReports\Reports\DCDiag_$(Get-Date -Format yyyyMMdd).txt"
dcdiag /c /v /f:$Out