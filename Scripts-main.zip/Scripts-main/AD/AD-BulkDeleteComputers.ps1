﻿# Path to the text file containing computer names (one name per line)
$computerNamesFile = "C:\Users\venkatesh.k\Downloads\AD\ComputerNames.txt"

# Read the computer names from the text file
$computerNames = Get-Content $computerNamesFile

# Perform the deletion for each computer name
foreach ($computerName in $computerNames) {
    # Check if the computer exists in Active Directory
    if (Get-ADComputer -Filter { Name -eq $computerName }) {
        # Delete the computer from Active Directory
        Remove-ADComputer -Identity $computerName -Confirm:$false
        Write-Host "Computer '$computerName' has been deleted from Active Directory."
    } else {
        Write-Host "Computer '$computerName' not found in Active Directory. Skipping deletion."
    }
}
