Search-ADAccount -AccountDisabled -UsersOnly |
    Select Name, SamAccountName |
    Export-Csv "C:\ADReports\Reports\DisabledUsers_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation