$CutOff = (Get-Date).AddDays(-7)
Get-ADObject -Filter {whenCreated -ge $CutOff} -Properties Name, ObjectClass, whenCreated |
Where-Object { $_.ObjectClass -in @("user", "computer") } |
Select Name, ObjectClass, whenCreated |
Export-Csv "C:\ADReports\Reports\RecentObjects_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation