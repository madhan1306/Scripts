# Import the Active Directory module
Import-Module ActiveDirectory

# Path to the text file containing the list of usernames (one username per line)
$usernamesFile = "C:\Users\venkatesh.k\Downloads\aduser.txt"

# Check if the usernames file exists
if (Test-Path $usernamesFile) {
    # Read the list of usernames from the file
    $usernames = Get-Content $usernamesFile

    # Iterate through each username
    foreach ($username in $usernames) {
        # Trim leading and trailing whitespace from the username
        $username = $username.Trim()

        # Get the user object from Active Directory
        $user = Get-ADUser -Filter "SamAccountName -eq '$username'"

        if ($user -ne $null) {
            # Set the "Change password at next logon" option
            Set-ADUser -Identity $user -ChangePasswordAtLogon $true

            Write-Host "Successfully set 'Change password at next logon' for user $username"
        } else {
            Write-Warning "User $username not found in Active Directory"
        }
    }
} else {
    Write-Warning "Usernames file not found at $usernamesFile"
}
