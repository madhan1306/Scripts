﻿# Import Active Directory module Test
Import-Module ActiveDirectory

# Set the output file path for the CSV file
$outputCSV = "C:\Users\venkatesh.k\Downloads\AD\PasswordNeverExpiresUsers.csv"

# Get active user accounts with "Password Never Expires" attribute set to true
$activeUsers = Get-ADUser -Filter {Enabled -eq $true -and PasswordNeverExpires -eq $true} -Properties Name, SamAccountName, PasswordNeverExpires

# Export the list of active users with "Password Never Expires" to a CSV file
$activeUsers | Select-Object Name, SamAccountName, PasswordNeverExpires | Export-Csv -Path $outputCSV -NoTypeInformation

Write-Host "List of active users with 'Password Never Expires' exported to $outputCSV"
