$Date = (Get-Date).AddDays(-90)
Get-ADUser -Filter {LastLogonTimeStamp -lt $Date -and Enabled -eq $true} -Properties LastLogonTimeStamp |
Select Name, SamAccountName, @{Name='LastLogonDate';Expression={[datetime]::FromFileTime($_.LastLogonTimeStamp)}} |
Export-Csv "C:\ADReports\Reports\InactiveUsers_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation