﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Define the new information details
$webpage = "www.SunTechnologies.com"


# Retrieve all users in the domain
$allUsers = Get-ADUser -Filter * -Properties HomePage, Office

# Loop through each user and update the attributes
foreach ($user in $allUsers) {
    try {
        # Update "Webpage" and "Office" fields
        Set-ADUser -Identity $user.SamAccountName -HomePage $webpage -Office $office
        Write-Host "Updated Webpage and Office fields for user: $($user.SamAccountName)"
    } catch {
        Write-Host "Failed to update attributes for user: $($user.SamAccountName). Error: $_"
    }
}

# Confirm the updates for a few sample users
$sampleUsers = Get-ADUser -Filter * -Properties HomePage | Select-Object -First 5
$sampleUsers | Select-Object SamAccountName, HomePage
