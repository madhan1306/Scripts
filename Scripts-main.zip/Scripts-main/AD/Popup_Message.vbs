MsgBox "Your PC will reboot in 5 minutes in response to system maintenance.Please save your work." & vbCrLf & _
       "-" & vbCrLf & _
       "Thank You", vbOKOnly + vbInformation, "Notice :: IT Support - Sun Technologies Inc"
