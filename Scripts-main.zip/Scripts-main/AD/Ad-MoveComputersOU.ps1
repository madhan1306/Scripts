﻿# Path to your text file containing computer names (one per line) 
$ComputerListPath = "C:\Users\venkatesh.k\Downloads\us-pc.txt"

# Destination OU
$TargetOU = "OU=Desktops,OU=USOFF,DC=STI,DC=COM"

# Import Active Directory module
Import-Module ActiveDirectory

# Read computer names from the text file
$ComputerNames = Get-Content -Path $ComputerListPath | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }

foreach ($ComputerName in $ComputerNames) {
    # Try to get the computer object from AD
    $ADComputer = Get-ADComputer -Filter { Name -eq $ComputerName } -ErrorAction SilentlyContinue

    if ($ADComputer) {
        try {
            Move-ADObject -Identity $ADComputer.DistinguishedName -TargetPath $TargetOU -ErrorAction Stop
            Write-Host "Moved $ComputerName to $TargetOU" -ForegroundColor Green
        }
        catch {
            Write-Warning ("Failed to move {0}: {1}" -f $ComputerName, $_.Exception.Message)
        }
    }
    else {
        Write-Host "Computer $ComputerName does not exist in AD. Skipping." -ForegroundColor Yellow
    }
}
