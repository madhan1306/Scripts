﻿# Define the number of notifications and the interval
$notificationCount = 2
$notificationInterval = 15 # in minutes

# Function to show notification
function Show-Notification {
    param (
        [string]$message
    )
    [System.Windows.Forms.MessageBox]::Show($message, "Reboot Required", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
}

# Notify the user twice
for ($i = 1; $i -le $notificationCount; $i++) {
    Show-Notification "Your computer needs to restart. Please save your work. This is notification $i of $notificationCount."
    Start-Sleep -Seconds ($notificationInterval * 60) # Wait for 15 minutes
}

# Force a reboot after notifications
shutdown.exe /r /f /t 0
