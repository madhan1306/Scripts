$Groups = @("Domain Admins", "Enterprise Admins", "Schema Admins")
$OutFile = "C:\ADReports\Reports\PrivilegedUsers_$(Get-Date -Format yyyyMMdd).csv"
$Results = foreach ($Group in $Groups) {
    Get-ADGroupMember -Identity $Group -Recursive |
    Select-Object @{Name="Group";Expression={$Group}}, Name, SamAccountName
}
$Results | Export-Csv $OutFile -NoTypeInformation