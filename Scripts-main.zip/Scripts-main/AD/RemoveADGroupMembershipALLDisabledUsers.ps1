﻿# Import Active Directory module
Import-Module ActiveDirectory

# Get all disabled user accounts in the Active Directory
$disabledUsers = Get-ADUser -Filter {Enabled -eq $false} -Properties MemberOf

# Loop through each disabled user and remove group membership
foreach ($user in $disabledUsers) {
    $userDN = $user.DistinguishedName

    # Retrieve current group membership
    $memberOf = $user.MemberOf

    if ($memberOf) {
        # Remove user from each group
        foreach ($group in $memberOf) {
            Remove-ADGroupMember -Identity $group -Members $userDN -Confirm:$false
        }
        
        Write-Host "Group membership removed for user: $($user.SamAccountName)"
    }
    else {
        Write-Host "No group membership found for user: $($user.SamAccountName)"
    }
}
