﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Define the new address details
$streetAddress = "Sun Technology Integrators Pvt. Ltd,
No.496, 1st stage,4th Block, HBR Layout, 
Bangalore 560043"
$city = "Bangalore"
$state = "Karnataka"
$postalCode = "560043"
$country = "India"

# Retrieve all users in the domain
$allUsers = Get-ADUser -Filter * -Properties StreetAddress, City, State, PostalCode, Country

# Loop through each user and update the address attributes
foreach ($user in $allUsers) {
    try {
        # Update StreetAddress
        Set-ADUser -Identity $user.SamAccountName -StreetAddress $streetAddress
        Write-Host "Street address updated successfully for user: $($user.SamAccountName)"

        # Update City
        Set-ADUser -Identity $user.SamAccountName -City $city
        Write-Host "City updated successfully for user: $($user.SamAccountName)"

        # Update State
        Set-ADUser -Identity $user.SamAccountName -State $state
        Write-Host "State updated successfully for user: $($user.SamAccountName)"

        # Update PostalCode
        Set-ADUser -Identity $user.SamAccountName -PostalCode $postalCode
        Write-Host "Postal code updated successfully for user: $($user.SamAccountName)"

        # Update Country
        Set-ADUser -Identity $user.SamAccountName -Country $country
        Write-Host "Country updated successfully for user: $($user.SamAccountName)"
    } catch {
        Write-Host "Failed to update address for user: $($user.SamAccountName). Error: $_"
    }
}

# Confirm the updates for a few sample users
$sampleUsers = Get-ADUser -Filter * -Properties StreetAddress, City, State, PostalCode, Country | Select-Object -First 5
$sampleUsers | Select-Object SamAccountName, StreetAddress, City, State, PostalCode, Country
