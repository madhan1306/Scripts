﻿# Import the Active Directory module
Import-Module ActiveDirectory

# Define the new office location
$office = "US Office"

# Specify the distinguished name (DN) of the target OU
$ouDN = "OU=USOffice,DC=STI,DC=COM"

# Retrieve users from the target OU
$usersInOU = Get-ADUser -Filter * -SearchBase $ouDN -Properties Office

# Loop through each user in the OU and update the "Office" attribute
foreach ($user in $usersInOU) {
    try {
        # Update "Office" attribute
        Set-ADUser -Identity $user.SamAccountName -Office $office
        Write-Host "Updated Office attribute for user $($user.SamAccountName)"
    } catch {
        Write-Host "Failed to update Office attribute for user $($user.SamAccountName). Error: $_"
    }
}
