$Days = 60
$CutOff = (Get-Date).AddDays(-$Days)
Get-ADComputer -Filter * -Properties LastLogonDate |
Where-Object { $_.LastLogonDate -lt $CutOff } |
Select Name, LastLogonDate |
Export-Csv "C:\ADReports\Reports\StaleComputers_$(Get-Date -Format yyyyMMdd).csv" -NoTypeInformation