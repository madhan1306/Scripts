﻿$serverName = $env:COMPUTERNAME
$timestamp = Get-Date -Format "dd-MM-yyyy"
$folderPath = "E:\DFS-SHARE\Replication-Test\$timestamp\"

# Create the folder if it doesn't exist
if (-not (Test-Path -Path $folderPath)) {
    New-Item -Path $folderPath -ItemType Directory | Out-Null
}

$outputFile = "$folderPath\DFSRBacklog_${serverName}_$timestamp.txt"

# Full path to your actual script
& "C:\Scripts\DFS\Get-DFSRBacklog-DC07.ps1" >> $outputFile