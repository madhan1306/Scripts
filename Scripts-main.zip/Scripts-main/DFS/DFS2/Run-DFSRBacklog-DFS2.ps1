﻿$serverName = $env:COMPUTERNAME
$timestamp = Get-Date -Format "dd-MM-yyyy"
$folderPath = "\\STIPL-SRV-DFS1\Replication-Test\$timestamp"

# Create the folder if it doesn't exist
if (-not (Test-Path -Path $folderPath)) {
    New-Item -Path $folderPath -ItemType Directory | Out-Null
}

# Define the output file path
$outputFile = Join-Path -Path $folderPath -ChildPath "DFSRBacklog_${serverName}_$timestamp.txt"

# Execute the DFSR backlog script and redirect output
& "C:\Scripts\DFS\Get-DFSRBacklog-DFS2.ps1" | Out-File -FilePath $outputFile -Encoding UTF8
