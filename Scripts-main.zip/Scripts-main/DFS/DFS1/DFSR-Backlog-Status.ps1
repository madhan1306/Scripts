﻿# ===== CONFIGURATION =====
$today = Get-Date -Format "dd-MM-yyyy"
$BaseFolder = "E:\DFS-SHARE\Replication-Test"
$ReplicaCheckFolder = Join-Path $BaseFolder $today  # e.g., \\server02\Test\14-07-2025

$SmtpServer = "suntechnologies-com.mail.protection.outlook.com"
$SmtpPort = 25
$EmailFrom = "venkatesh.krishna@suntechnologies.com"
$EmailTo = "venkatesh.krishna@suntechnologies.com"
$EmailSubject = "[Automated] DFS Server's Replication Status"

# ===== CHECK FOLDER EXISTS =====
if (-not (Test-Path $ReplicaCheckFolder)) {
    Write-Host "❌ Today's folder not found: $ReplicaCheckFolder"
    exit
}

# ===== READ LOG FILES AND CHECK BACKLOG =====
Write-Host "`n🔍 Scanning replicated logs in: $ReplicaCheckFolder"
$results = @()
$replicatedOk = $true

# Read both .txt and .log files
$logFiles = Get-ChildItem -Path $ReplicaCheckFolder -Filter *.txt -File
$logFiles += Get-ChildItem -Path $ReplicaCheckFolder -Filter *.log -File

foreach ($file in $logFiles) {
    $content = Get-Content $file.FullName -Raw
    $blocks = $content -split "(?=ReplicationGroupName\s*:)"

    foreach ($block in $blocks) {
        if ($block -match "BacklogCount\s*:\s*(\d+)" -and [int]$matches[1] -gt 0) {
            $BacklogCount = [int]$matches[1]
            $ReplicationGroupName = ""
            $ReplicatedFolderName = ""
            $SendingMember = ""
            $ReceivingMember = ""

            if ($block -match "ReplicationGroupName\s*:\s*(.+)")   { $ReplicationGroupName = $matches[1].Trim() }
            if ($block -match "ReplicatedFolderName\s*:\s*(.+)")   { $ReplicatedFolderName = $matches[1].Trim() }
            if ($block -match "SendingMember\s*:\s*(.+)")          { $SendingMember = $matches[1].Trim() }
            if ($block -match "ReceivingMember\s*:\s*(.+)")        { $ReceivingMember = $matches[1].Trim() }

            $results += [PSCustomObject]@{
                ReplicationGroupName  = $ReplicationGroupName
                ReplicatedFolderName  = $ReplicatedFolderName
                SendingMember         = $SendingMember
                ReceivingMember       = $ReceivingMember
                BacklogCount          = $BacklogCount
            }
        }
    }
}

# ===== GENERATE HTML EMAIL =====
$html = @"
<html><body>
<h4>    DFSR Replication Backlog Check : $today </h4>
<hr>
"@

if ($results.Count -gt 0) {
    $html += @"
<h5>Please find the Replication Backlog Report (BacklogCount > 0)</h5>
<table style='border-collapse: collapse; width: 100%;'>
<tr style='background-color:#f2f2f2;'>
<th style='border: 1px solid #888;'>ReplicationGroupName</th>
<th style='border: 1px solid #888;'>ReplicatedFolderName</th>
<th style='border: 1px solid #888;'>SendingMember</th>
<th style='border: 1px solid #888;'>ReceivingMember</th>
<th style='border: 1px solid #888;'>BacklogCount</th>
</tr>
"@

    foreach ($row in $results) {
        $html += "<tr>
<td style='border:1px solid #888;'>$($row.ReplicationGroupName)</td>
<td style='border:1px solid #888;'>$($row.ReplicatedFolderName)</td>
<td style='border:1px solid #888;'>$($row.SendingMember)</td>
<td style='border:1px solid #888;'>$($row.ReceivingMember)</td>
<td style='border:1px solid #888;'>$($row.BacklogCount)</td>
</tr>`n"
    }

    $html += "</table>"
} else {
    $html += "<p><b>No backlog issues detected.</b></p>"
}

#$html += "</body></html>"

$html += @"
<br><hr>
<p style='font-size:12px; font-family:Segoe UI, sans-serif; color:#555;'>
Thanks,<br>
<b>Venkatesh Krishna</b><br>
IT Department | Sun Technology Integrators Pvt Ltd<br>
</p>
</body></html>
"@


# ===== SEND EMAIL =====
Send-MailMessage -From $EmailFrom -To $EmailTo -Subject $EmailSubject `
    -BodyAsHtml -Body $html -SmtpServer $SmtpServer -Port $SmtpPort

Write-Host "`n📧 Email sent with backlog report."
