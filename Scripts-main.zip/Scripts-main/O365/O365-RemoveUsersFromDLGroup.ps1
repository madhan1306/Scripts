﻿# Connect to Exchange Online
Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowProgress $true

# Define the path to the text file containing the list of user mailboxes (one email address per line)
$userListFile = "C:\Users\venkatesh.k\Downloads\GA.txt"

# Get the content of the text file
$userMailboxes = Get-Content $userListFile

# Loop through each user mailbox
foreach ($mailbox in $userMailboxes) {
    # Get the distribution groups the user is a member of
    $groups = Get-DistributionGroup | Where-Object { (Get-DistributionGroupMember $_.Identity | Where-Object { $_.PrimarySmtpAddress -eq $mailbox }) }

    # Remove the user from each distribution group
    foreach ($group in $groups) {
        Remove-DistributionGroupMember -Identity $group.Identity -Member $mailbox -Confirm:$false
        Write-Host "Removed $mailbox from distribution group: $($group.DisplayName)"
    }
}
