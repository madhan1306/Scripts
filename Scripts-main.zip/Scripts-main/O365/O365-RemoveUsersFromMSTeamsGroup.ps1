﻿# Connect to Exchange Online
Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowProgress $true 

# Define the path to the text file containing the user email addresses (one email address per line)
$userEmailFile = "C:\Users\venkatesh.k\Downloads\GA.txt"

# Get the content of the text file
$userEmails = Get-Content $userEmailFile

# Iterate through each user email address
foreach ($userEmail in $userEmails) {
    # Get all Microsoft 365 Unified Groups the user is a member of
    $unifiedGroups = Get-UnifiedGroup -ResultSize Unlimited | Where-Object { (Get-UnifiedGroupLinks -Identity $_.Identity -LinkType Members).PrimarySmtpAddress -contains $userEmail }

    # Remove the user from each Microsoft 365 Unified Group
    foreach ($group in $unifiedGroups) {
        Remove-UnifiedGroupLinks -Identity $group.Identity -LinkType Members -Links $userEmail -Confirm:$false
        Write-Host "Removed $userEmail from Microsoft 365 Unified Group: $($group.DisplayName)"
    }
}
