Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com

Get-DistributionGroupMember -Identity "0db0274b-1283-4770-8533-9b499a4749c7" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\sun-appdev.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "dfdcd86f-a691-46d5-bfd4-94d3ffc06362" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\qa_manual.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "e7b34d48-624c-4811-b67a-749d24f7167e" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\qa_automation.csv -NoTypeInformation

Get-DistributionGroupMember -Identity "caee1f88-d910-4ba8-9084-bff70747f6aa" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\acc_ind.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "89542242-63f1-4e33-9193-06105586826d" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\accountsteam.csv -NoTypeInformation

Get-DistributionGroupMember -Identity "fe45efb6-3cbf-44a5-8c4b-dd43f4ef8099" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\exe_admin.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "ba9876a4-f86b-4cef-9b09-d68dff829e06" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\facility_ind.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "331bf410-fc8c-448c-b1c7-235b94dbc299" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\facility_forwarding.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "16af4055-a8a9-4a1e-9e15-b2fe93bb358b" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\facilityteam.csv -NoTypeInformation

Get-DistributionGroupMember -Identity "46a113d3-1005-4ad7-8f82-5237a4a0e3df" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\hr1.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "1041674a-7365-445c-a75e-c8936b7804df" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\hrmteam.csv -NoTypeInformation

Get-DistributionGroupMember -Identity "958118ea-5043-4acf-b22f-c1c1a296b816" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\sit.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "8180aa04-5889-48b8-9a6b-39836402108f" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\itsupport_forwarding.csv -NoTypeInformation

Get-DistributionGroupMember -Identity "1407affd-8408-4398-80a5-fa99b90798ab" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\qagaming.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "58e6a1f8-788c-4a34-81ad-1389aa6933e4" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\gamedev.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "53b14316-b03b-4d6a-aae7-fb3a84908931" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\aavegadev.csv -NoTypeInformation

Get-DistributionGroupMember -Identity "66f43ffe-ccf3-4d08-b476-c12e88370b7c" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\mgs_mktg.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "5d7d4c61-cae7-47a7-8d15-087480393f72" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\macys_offshore.csv -NoTypeInformation
Get-DistributionGroupMember -Identity "41881249-5508-4c98-acf0-f4d6a1cc9696" | Select-Object DisplayName, Alias, PrimarySmtpAddress | Export-Csv -Path C:\Users\venkatesh.k\Downloads\DL\usrec.csv -NoTypeInformation





