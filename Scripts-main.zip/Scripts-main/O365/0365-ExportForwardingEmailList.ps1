﻿# Connect to Exchange Online
$UserCredential = Get-Credential
Connect-ExchangeOnline -Credential $UserCredential

# Get all mailboxes with forwarding enabled
$forwardingList = Get-Mailbox -ResultSize Unlimited | Where-Object { $_.ForwardingSmtpAddress -ne $null } | Select-Object DisplayName, ForwardingSmtpAddress, DeliverToMailboxAndForward

# Export the results to a CSV file
$forwardingList | Export-Csv -Path "C:\Users\venkatesh.k\Downloads\Email-Fwd-List-test.csv" -NoTypeInformation

# Disconnect from Exchange Online
Disconnect-ExchangeOnline -Confirm:$false