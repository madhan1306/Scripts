# Connect to Exchange Online (if not already connected)
try {
    if (-not (Get-Module ExchangeOnlineManagement -ListAvailable)) {
        Install-Module ExchangeOnlineManagement -Force
    }
    Import-Module ExchangeOnlineManagement
    Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowBanner:$False 
}
catch {
    Write-Host "Failed to connect to Exchange Online: $_" -ForegroundColor Red
    exit
}

# Import CSV file
# CSV should have headers: DistributionList, UserEmail
$csvPath = "C:\Users\venkatesh.k\Downloads\AddUsersToDL.csv"
$users = Import-Csv -Path $csvPath

foreach ($entry in $users) {
    try {
        Add-DistributionGroupMember -Identity $entry.DistributionList -Member $entry.UserEmail -ErrorAction Stop
        Write-Host "✅ Added $($entry.UserEmail) to $($entry.DistributionList)" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Failed to add $($entry.UserEmail) to $($entry.DistributionList): $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Disconnect session after completion
Disconnect-ExchangeOnline -Confirm:$false
