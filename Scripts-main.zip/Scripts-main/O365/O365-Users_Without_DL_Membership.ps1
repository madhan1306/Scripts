﻿# Connect to Exchange Online
try {
    if (-not (Get-Module ExchangeOnlineManagement -ListAvailable)) {
        Install-Module ExchangeOnlineManagement -Force
    }
    Import-Module ExchangeOnlineManagement
    Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com
}
catch {
    Write-Host "Failed to connect to Exchange Online: $_" -ForegroundColor Red
    exit
}

Write-Host "Fetching all mail users and distribution lists..." -ForegroundColor Cyan

# Get all mail-enabled users
$allUsers = Get-MailUser -ResultSize Unlimited
$allMailboxes = Get-Mailbox -ResultSize Unlimited
$allRecipients = $allUsers + $allMailboxes

# Get all distribution groups
$allDLs = Get-DistributionGroup -ResultSize Unlimited

# Create an array to track members across all DLs
$allGroupMembers = @()

foreach ($dl in $allDLs) {
    $members = Get-DistributionGroupMember -Identity $dl.Identity -ResultSize Unlimited -ErrorAction SilentlyContinue
    if ($members) {
        $allGroupMembers += $members.PrimarySmtpAddress
    }
}

# Find users not in any group
$usersWithoutDL = $allRecipients | Where-Object { $_.PrimarySmtpAddress -notin $allGroupMembers }

Write-Host "Users without any Distribution List membership:" -ForegroundColor Yellow
$usersWithoutDL | Select-Object DisplayName, PrimarySmtpAddress | Format-Table -AutoSize

# Optional: Export to CSV
$exportPath = "C:\Users_Without_DL_Membership.csv"
$usersWithoutDL | Select-Object DisplayName, PrimarySmtpAddress | Export-Csv -Path $exportPath -NoTypeInformation
Write-Host "Report exported to $exportPath" -ForegroundColor Green

# Disconnect session
Disconnect-ExchangeOnline -Confirm:$false
