﻿Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowBanner:$False 

$DistributionLists = Get-DistributionGroup -ResultSize Unlimited
foreach ($DL in $DistributionLists) {
    $Members = Get-DistributionGroupMember -Identity $DL.Identity
    $Members | Select-Object @{Name='DistributionList';Expression={$DL.DisplayName}}, Name, PrimarySmtpAddress | Export-Csv -Append -Path "C:\O365.All.DL.Members.csv" -NoTypeInformation
}
