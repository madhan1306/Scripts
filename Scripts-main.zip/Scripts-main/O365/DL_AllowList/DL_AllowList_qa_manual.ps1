#Allowed members in "QA Manual"
Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowBanner:$False

Set-DistributionGroup -Identity "qa_manual@suntechnologies.com" -AcceptMessagesOnlyFromSendersOrMembers "ashwinir@suntechnologies.com","hrmadmin@suntechnologies.com",
"hr@suntechnologies.com",
"facility@suntechnologies.com",
"bala@suntechnologies.com",
"ravi@suntechnologies.com",
"anitha@suntechnologies.com",
"prakashn@suntechnologies.com",
"saleema@suntechnologies.com",
"sanjay@suntechnologies.com",
"priyav@suntechnologies.com",
"thejaswinim@suntechnologies.com",
"sandeepn@suntechnologies.com",
"prathibhab@suntechnologies.com",
"malathi@suntechnologies.com",
"manjunathan@suntechnologies.com",
"satish@suntechnologies.com",
"itsupport@suntechnologies.com",
"senthilkumars@suntechnologies.com"