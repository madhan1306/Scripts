#Allowed members in "AppDev" 

Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowBanner:$False

Set-DistributionGroup -Identity "sun-appdev@suntechnologies.com" -AcceptMessagesOnlyFromSendersOrMembers "ashwinir@suntechnologies.com","hrmadmin@suntechnologies.com",
"facility@suntechnologies.com","bala@suntechnologies.com","ravi@suntechnologies.com","anitha@suntechnologies.com",
"prakashn@suntechnologies.com","saleema@suntechnologies.com","sanjay@suntechnologies.com","yoganandaswamyr@suntechnologies.com",
"priyav@suntechnologies.com","thejaswinim@suntechnologies.com","sandeepn@suntechnologies.com","prathibhab@suntechnologies.com","malathi@suntechnologies.com","manjunathan@suntechnologies.com",
"satish@suntechnologies.com","itsupport@suntechnologies.com",hr@suntechnologies.com
