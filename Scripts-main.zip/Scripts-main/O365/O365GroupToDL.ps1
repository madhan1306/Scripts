﻿# Connect to Exchange Online PowerShell
Connect-ExchangeOnline -UserPrincipalName admin@suntechind.onmicrosoft.com -ShowProgress $true -ShowBanner:$false

# Get the group by email address
$group = Get-UnifiedGroup -Identity "testdl@suntechnologies.com" 

# Remove the group
Remove-UnifiedGroup -Identity $group.Identity
Start-Sleep -Seconds 30

# Define the distribution list name
$dlName = "testdl"

# Read members from the text file
$members = Get-Content -Path "C:\Users\venkatesh.k\Downloads\members.txt"

New-DistributionGroup -Name "testdl" -DisplayName "testdl" -Alias "testdl" -PrimarySmtpAddress "testdl@suntechnologies.com" -ManagedBy "venkatesh.krishna"
Set-DistributionGroup "testdl" -RequireSenderAuthenticationEnabled $False 

# Add members to the distribution list
foreach ($member in $members) {
    try {
        # Trim any extra spaces and ensure the member is added correctly
        Add-DistributionGroupMember -Identity $dlName -Member $member.Trim()
        Write-Host "Added $member to $dlName"
    } catch {
        Write-Host "Failed to add $member to $dlName"
    }
}
