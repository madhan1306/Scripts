﻿$queryOutput = query user 2>$null

if (-not $queryOutput) {
    Write-Host "CRITICAL: Failed to retrieve user sessions"
    exit 2
}

# Convert to usable objects
$users = $queryOutput -replace "\s{2,}", "," | ConvertFrom-Csv -Header "Username","SessionName","ID","State","IdleTime","LogonTime"

# Filter only Active sessions
$activeUsers = $users | Where-Object { $_.State -eq "Active" -and $_.Username -ne "" }

# Count and display
$count = ($activeUsers | Measure-Object).Count
$usernames = ($activeUsers | ForEach-Object { $_.Username.Trim() }) -join ", "

Write-Host "OK: $count active user(s) logged in - $usernames"
exit 0