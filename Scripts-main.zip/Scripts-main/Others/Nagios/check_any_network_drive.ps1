﻿# Check Mapped Network Drives
$MappedDrives = Get-WmiObject -Query "SELECT * FROM Win32_LogicalDisk WHERE DriveType = 4" | Select-Object -ExpandProperty ProviderName

# Check Active SMB Connections
#$SMBConnections = Get-SmbConnection | Select-Object -ExpandProperty ShareName

# Combine Results
$NetworkDrives = $MappedDrives + $SMBConnections

# Validate if network drives are found
if ($NetworkDrives) {
    Write-Output "OK: Network drives are mounted."
    foreach ($Drive in $NetworkDrives) {
        Write-Output $Drive
    }
    exit 0  # Exit code 0 for OK
} else {
    Write-Output "CRITICAL: No network drives are mounted."
    exit 2  # Exit code 2 for CRITICAL
}
