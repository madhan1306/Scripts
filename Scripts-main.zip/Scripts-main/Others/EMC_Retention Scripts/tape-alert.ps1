﻿$FilePath = "C:\Program Files\EMC NetWorker\nsr\logs\messages.log"
$LogFile = "C:\Users\Administrator\Desktop\daemon_MonitorLog.txt"
$SmtpServer = "suntechnologies-com.mail.protection.outlook.com"
$From = "itn@suntechnologies.com"
$To = @("dm@suntechnologies.com")
$Subject = "Alert: Insert LTO Tape for Backup | Writable Volume detected"
$Body = @" 
Hi,

Please insert the next tape to continue the Backup/Cloning process.

ServerName : STIPL-SRV-TAPE

IMPORTANT: Insert within 30 minutes, if not this alert repeats every 10 minutes.



Thanks,
Venkatesh Krishna
System Administrator
IT Department | Sun Technology Integrators Pvt Ltd

"@
        

# Function to log messages with timestamps and ensure log file exists
function Write-Log {
    param ([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $LogMessage = "$Timestamp - $Message"
    Write-Host $LogMessage  # Display in console
    Add-Content -Path $LogFile -Value $LogMessage -Force  # Create and write log file
}

# Ensure the log file exists
if (-not (Test-Path $LogFile)) {
    New-Item -ItemType File -Path $LogFile -Force | Out-Null
}

function Monitor-File {
    Write-Log "Checking file: $FilePath"

    if (Test-Path $FilePath) {
        # Read last 15 lines from the file
        $LastLines = Get-Content -Path $FilePath -Tail 4

        # Check if the message exists in the last 10 lines
        if ($LastLines -match "waiting for 1 writable volume" -or $LastLines -match "waiting for LTO")		{
            Write-Log "ALERT: Message found in last 2 lines!"

            # Send email alert
            try {
                Send-MailMessage -SmtpServer $SmtpServer -From $From -To $To -Subject $Subject -Body $Body -Port 25
                Write-Log "Email alert sent successfully to $To"
            } catch {
                Write-Log "ERROR: Failed to send email - $_"
            }
        } else {
            Write-Log "No matching message found in last 10 lines."
        }
    } else {
        Write-Log "ERROR: File not found: $FilePath"
    }

    Write-Log "Script execution completed. Exiting..."
}

# Run the monitoring function once and exit
Monitor-File
