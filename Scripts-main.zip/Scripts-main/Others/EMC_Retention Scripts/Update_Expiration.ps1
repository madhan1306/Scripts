﻿# Define the volume name and new expiration date
$newRetentionDate="09/03/2024"
# Read the list of SSIDs from the file
$ssids = Get-Content -Path "C:\Users\Administrator\Desktop\Retention Scripts\ssids.txt"

# Loop through each SSID and change its expiration date
foreach ($ssid in $ssids) {
    if ($ssid -ne "") {
        Write-Host "Changing expiration for SSID: $ssid to $newRetentionDate"
        $process = Start-Process nsrmm -ArgumentList "-S $ssid", "-e $newRetentionDate", "-y" -NoNewWindow -Wait -PassThru
        if ($process.ExitCode -ne 0) {
            Write-Host "Failed to change expiration for SSID: $ssid" -ForegroundColor Red
        }
    }
}

Write-Host "Expiration dates updated for all SSIDs on volume: $volumeName."
