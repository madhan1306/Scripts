﻿Write-Output "Checking and installing updates on $env:COMPUTERNAME..."

# Create the Windows Update session
$UpdateSession = New-Object -ComObject Microsoft.Update.Session
$UpdateSearcher = $UpdateSession.CreateUpdateSearcher()

# Search for applicable updates
$SearchResult = $UpdateSearcher.Search("IsInstalled=0 and Type='Software'")

if ($SearchResult.Updates.Count -eq 0) {
    Write-Output "No updates found."
    exit 0
}

Write-Output "$($SearchResult.Updates.Count) update(s) found. Proceeding with installation..."

# Prepare updates to install
$UpdatesToInstall = New-Object -ComObject Microsoft.Update.UpdateColl

foreach ($Update in $SearchResult.Updates) {
    if (-not $Update.EulaAccepted) {
        $Update.AcceptEula()
    }
    $UpdatesToInstall.Add($Update) | Out-Null
}

# Download the updates
$Downloader = $UpdateSession.CreateUpdateDownloader()
$Downloader.Updates = $UpdatesToInstall
$Downloader.Download()

# Install the updates
$Installer = $UpdateSession.CreateUpdateInstaller()
$Installer.Updates = $UpdatesToInstall
$Installer.ForceQuiet = $true
$Installer.AllowSourcePrompts = $false

$Result = $Installer.Install()

Write-Output "Installation Result Code: $($Result.ResultCode)"
Write-Output "Reboot Required: $($Result.RebootRequired)"
