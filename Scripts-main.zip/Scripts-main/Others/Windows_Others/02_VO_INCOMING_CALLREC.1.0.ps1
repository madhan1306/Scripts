# ==============================
# VOIP Incoming Call Sort Script 
# ==============================

$UserPhoneDetails = "S:\VOIP Office recording\2025\Users_Extn_Phone.txt"
$RawFolder        = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025"
$DestinationRoot  = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025\IncomingCalls"

# --- Read Users_Extn_Phone.txt ---
$Users = Import-Csv -Path $UserPhoneDetails -Header Username,Extension,Phone

# Build lookup by Phone
$PhoneLookup = @{}
foreach ($U in $Users) {
    $PhoneLookup[$U.Phone.Trim()] = @{
        Username  = $U.Username.Trim()
        Extension = $U.Extension.Trim()
    }
}

# Process all mp3 files
$Files = Get-ChildItem -Path $RawFolder -Recurse -File -Filter *.mp3

foreach ($File in $Files) {
    # Example filename:
    # 29 Sep 2025 09-37-23 AM-13013836049-6785721895-1759153043.1931309.mp3
    # Split by '-'
    $Parts = $File.BaseName -split "-"

    if ($Parts.Count -ge 3) {
        $ExternalNumber = $Parts[-3]  # Caller ID
        $PhoneNumber    = $Parts[-2]  # Callee (our user)

        if ($PhoneLookup.ContainsKey($PhoneNumber)) {
            $User     = $PhoneLookup[$PhoneNumber]
            $UserName = $User.Username
            $Ext      = $User.Extension

            # Destination Folder
            $UserFolder = Join-Path $DestinationRoot "$UserName`_$Ext"

            if (!(Test-Path $UserFolder)) {
                New-Item -Path $UserFolder -ItemType Directory | Out-Null
            }

            # Copy file
            Copy-Item -Path $File.FullName -Destination $UserFolder -Force
        }
    }
}
