﻿# ==============================
# VOIP Outgoing Calls Call Sort Script (With No Logging, Folder Creation)
# ==============================

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

$SourcePath = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025"
$DestinationPath = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025"
$CsvFile = "S:\VOIP Office recording\2025\Users_Extn.txt"

# Read users from text file (username,extension per line)
$UserData = Get-Content -Path $CsvFile | ForEach-Object {
    if ($_ -match "^\s*(.+?)\s*,\s*(\d+)\s*$") {
        [PSCustomObject]@{
            Username  = $Matches[1].Trim()
            Extension = $Matches[2].Trim()
        }
    }
}

# Build lookup dictionary
$UserLookup = @{}
foreach ($row in $UserData) {
    Write-Host "Loaded: Username='$($row.Username)' Extension='$($row.Extension)'"  # Debug
    if ($row.Extension -and $row.Username) {
        $UserLookup[$row.Extension] = $row.Username
    }
}

# Create destination folder
if (!(Test-Path $DestinationPath)) {
    New-Item -ItemType Directory -Path $DestinationPath | Out-Null
}

# Process mp3 files
Get-ChildItem -Path $SourcePath -Recurse -Filter "*.mp3" | ForEach-Object {
    $FileName = $_.Name
    if ($FileName -match "-(\d{3,5})-") {
        $Extension = $Matches[1].Trim()
        Write-Host "Found file '$FileName' with extension '$Extension'"  # Debug

        if ($UserLookup.ContainsKey($Extension)) {
            $UserName = $UserLookup[$Extension]
            $FolderName = "${UserName}_$Extension"
        } else {
            $FolderName = "Unknown_$Extension"
        }

        $UserFolder = Join-Path $DestinationPath $FolderName
        if (!(Test-Path $UserFolder)) {
            New-Item -ItemType Directory -Path $UserFolder | Out-Null
        }

        Copy-Item -Path $_.FullName -Destination $UserFolder -Force
        Write-Host "Copied '$FileName' -> '$FolderName'"
    }
}
