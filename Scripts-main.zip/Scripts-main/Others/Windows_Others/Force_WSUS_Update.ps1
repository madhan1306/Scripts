﻿# Create log file
$LogPath = "C:\Windows\Temp\WSUS_Update_Log_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
Function Log { param($msg); $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"; "$timestamp - $msg" | Out-File -FilePath $LogPath -Append }

Log "Starting WSUS update process."

# Force scan
Log "Running: UsoClient StartScan"
UsoClient StartScan
Start-Sleep -Seconds 60

# Start download
Log "Running: UsoClient StartDownload"
UsoClient StartDownload
Start-Sleep -Seconds 60

# Start install
Log "Running: UsoClient StartInstall"
UsoClient StartInstall
Start-Sleep -Seconds 60

# Optional reboot if required (uncomment if needed)
# Log "Running: UsoClient RestartDevice"
# UsoClient RestartDevice

Log "WSUS update process completed."
