﻿# Function to send a Wake-on-LAN packet
function Send-WakeOnLan {
    param (
        [Parameter(Mandatory = $true)]
        [string]$MacAddress,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetIPAddress
    )
    
    $MacAddress = $MacAddress -replace "[:-]", ""  # Remove colons or dashes from MAC address

    if ($MacAddress.Length -ne 12) {
        throw "Invalid MAC address length. Ensure the MAC address is 12 hexadecimal characters."
    }

    # Create the magic packet
    $MagicPacket = New-Object byte[] 102
    for ($i = 0; $i -lt 6; $i++) {
        $MagicPacket[$i] = 0xFF
    }

    for ($i = 1; $i -le 16; $i++) {
        for ($j = 0; $j -lt 6; $j++) {
            $MagicPacket[6 * $i + $j] = [Convert]::ToByte($MacAddress.Substring(2 * $j, 2), 16)
        }
    }

    # Send the magic packet
    $UdpClient = New-Object System.Net.Sockets.UdpClient
    $Endpoint = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Parse($TargetIPAddress), 9)
    $BytesSent = $UdpClient.Send($MagicPacket, $MagicPacket.Length, $Endpoint)
    $UdpClient.Close()

    Log-Message "Magic packet sent to $MacAddress ($TargetIPAddress)"
}

# Function to log messages to a file
function Log-Message {
    param (
        [string]$message
    )
    $logFile = "E:\DR_Scripts\WakeOnLanDRLog.txt"
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] $message"
    $logMessage | Out-File -Append -FilePath $logFile
}

# Main script logic
$MacAddress = "F4:39:09:21:59:84"  # Replace with the target computer's MAC address
$TargetIPAddress = "172.18.39.56"  # Replace with the target computer's IP address
$IPAddress = "172.18.39.56"  # Replace with the target computer's IP address
$smtpServer = 'suntechnologies-com.mail.protection.outlook.com'

Log-Message "Starting Wake-on-LAN script."

$Ping = Test-Connection -ComputerName $IPAddress -Count 2 -Quiet

if ($Ping -eq $false) {
    Log-Message "PC is not responding. Sending Wake-on-LAN packet..."
    Send-WakeOnLan -MacAddress $MacAddress -TargetIPAddress $TargetIPAddress
} else {
    Log-Message "PC is online."
    exit
}

Start-Sleep 20

$Ping = Test-Connection -ComputerName $IPAddress -Count 2 -Quiet

if ($Ping -eq $false) {
    Log-Message "PC is still not responding after wake-up attempt."
    Send-WakeOnLan -MacAddress $MacAddress -TargetIPAddress $TargetIPAddress
    try {
        Send-MailMessage -From 'Madhan@suntechnologies.com' -To 'madhanc@suntechnologies.com' -Subject "Failure: (DR-Server) Unavailable" -Body "Server is not responding. Backups may fail, look into it immediately." -SmtpServer $smtpServer
        Log-Message "Failure email sent."
    } catch {
        Log-Message "Failed to send failure email: $_"
    }
} else {
    Log-Message "PC is online after wake-up attempt."
    try {
        Send-MailMessage -From 'Madhan@suntechnologies.com' -To 'madhanc@suntechnologies.com' -Subject "Success: DR-Server is Up" -Body "Server is up and running." -SmtpServer $smtpServer
        Log-Message "Success email sent."
    } catch {
        Log-Message "Failed to send success email: $_"
    }
}

Log-Message "Script finished."
