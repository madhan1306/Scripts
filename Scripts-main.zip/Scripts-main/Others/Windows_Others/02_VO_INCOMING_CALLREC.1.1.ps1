﻿# ==============================
# VOIP Incoming Call Sort Script (With Logging, No Folder Creation)
# ==============================

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

$UserPhoneDetails = "S:\VOIP Office recording\2025\Users_Extn_Phone.txt"
$RawFolder        = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025"
$DestinationRoot  = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025"
$LogFile          = "S:\VOIP Office recording\2025\10 - OCTOBER\VOIP_Office_Call_Recording_01-10-2025\IncomingCallCopyLog.txt"

"==== Script Started: $(Get-Date) ====" | Out-File $LogFile

# --- Read Users.txt ---
$Users = Import-Csv -Path $UserPhoneDetails -Header Username,Extension,Phone

# Build lookup by Phone
$PhoneLookup = @{}
foreach ($U in $Users) {
    $PhoneLookup[$U.Phone.Trim()] = @{
        Username  = $U.Username.Trim()
        Extension = $U.Extension.Trim()
    }
}

# Process all mp3 files
$Files = Get-ChildItem -Path $RawFolder -Recurse -File -Filter *.mp3

foreach ($File in $Files) {
    $Parts = $File.BaseName -split "-"

    if ($Parts.Count -ge 3) {
        $PhoneNumber = $Parts[-2]  # Callee (our user)

        if ($PhoneLookup.ContainsKey($PhoneNumber)) {
            $User     = $PhoneLookup[$PhoneNumber]
            $UserName = $User.Username
            $Ext      = $User.Extension

            # Destination Folder
            $UserFolder = Join-Path $DestinationRoot "$UserName`_$Ext"

            if (Test-Path $UserFolder) {
                Copy-Item -Path $File.FullName -Destination $UserFolder -Force
                Add-Content $LogFile "Copied: $($File.Name) -> $UserFolder"
            }
            else {
                Add-Content $LogFile "Skipped (no folder): $($File.Name) | User=$UserName Ext=$Ext"
            }
        }
        else {
            Add-Content $LogFile "Skipped (no match in Users.txt): $($File.Name)"
        }
    }
    else {
        Add-Content $LogFile "Invalid filename format: $($File.Name)"
    }
}

"==== Script Finished: $(Get-Date) ====" | Out-File $LogFile -Append
