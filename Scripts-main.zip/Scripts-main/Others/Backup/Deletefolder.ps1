$limit = (Get-Date).AddDays(-2)
$path = "\\172.18.39.56\DR_Copy\HRM"
$excludeFileName = "info.log"
# Delete files older than the $limit.
Get-ChildItem -Path $path -File -Recurse -Force | Where-Object { $_.CreationTime -lt $limit -and $_.Name -ne $excludeFileName } | Remove-Item -Force

# Delete folders older than the $limit.
Get-ChildItem -Path $path -Directory -Recurse -Force | Where-Object { $_.CreationTime -lt $limit } | Remove-Item -Force -Recurse