@echo off

REM Create a log file
set "logfile=E:\DR_Scripts\info.log"
set "bodyfile=E:\DR_Scripts\body.txt"
set "sign=E:\DR_Scripts\sign.txt"
setlocal enabledelayedexpansion

REM Set the directory to be zipped
set "sourceDirectory1=E:\wamp\www"

REM Set the directory to be zipped
set "sourceDirectory2=E:\HRM_Script"

for /f "tokens=1-2 delims=: " %%a in ("%TIME%") do (
     set "hour=%%a"
     set "minute=%%b"
)
if %hour% lss 10 set "hour=0%hour%"

REM Set the destination directory for the ZIP file
set "destinationDirectory=\\172.18.39.56\DR_Copy\HRM"

REM Set the output ZIP file name
set "zipFile1=HRM_App_!hour!!minute!.zip"
set "zipFile2=HRM_App_Scripts_!hour!!minute!.zip"

REM Change to the source directory 1
cd /d "%sourceDirectory1%"

REM Count the number of folders and files in the source directory
set "folderCountBefore=0"
set "fileCountBefore=0"
for /f %%a in ('dir /b /s /ad "%sourceDirectory1%" ^| find /c /v ""') do set "folderCountBefore=%%a"
for /f %%a in ('dir /b /s /a-d "%sourceDirectory1%" ^| find /c /v ""') do set "fileCountBefore=%%a"
for /r "%sourceDirectory1%" %%F in (*) do (
    REM Get the size of each file and add it to the total size
    for /f %%A in ("%%~zF") do set /a "totalSize+=%%A"
)

REM Outputs
echo %DATE%-!hour!:!minute! - Total folders in the HRM_App(www): %folderCountBefore% >> "%logfile%"
echo %DATE%-!hour!:!minute! - Total files in the HRM_App(www): %fileCountBefore% >> "%logfile%"
echo %DATE%-!hour!:!minute! - Total Size(HRM_App): %totalSize% >> "%logfile%"
echo Total folders in the HRM_App(www): %folderCountBefore% Folders. >> "%bodyfile%"
echo Total files in the HRM_App(www): %fileCountBefore% Files. >> "%bodyfile%"
echo Total Size(HRM_App): %totalSize% Bytes >> "%bodyfile%"

REM Create the ZIP file using 7-Zip
 "C:\Program Files\7-Zip\7z.exe" a "%destinationDirectory%\%DATE%\App\%zipFile1%" . && (
     echo %DATE%-!hour!:!minute! - HRM_App Zip created: %destinationDirectory%\%DATE%\App\%zipFile1% >> "%logfile%"
) || (
     echo %DATE%-!hour!:!minute! - Failed to create HRM_App Zip. Possible reasons: permission issues, missing files, etc. >> "%logfile%"
echo Hello Team, > "%temp%\email_content.txt"
    echo. >> "%temp%\email_content.txt"
    echo DR Backup is Failed. Please check logs for errors.  >> "%temp%\email_content.txt"
    REM echo. >> "%temp%\email_content.txt"
    echo. >> "%temp%\email_content.txt"
    echo. >> "%temp%\email_content.txt"
    type "%sign%" >> "%temp%\email_content.txt"    
    powershell.exe -ExecutionPolicy Bypass -command "Send-MailMessage -From 'Admin@HRM.sti.com' -To 'madhanc@suntechnologies.com' -Subject '(IMP) Failure: HRM DR Backup is Failed' -Body (Get-Content '%temp%\email_content.txt' -Raw) -SmtpServer 'suntechnologies-com.mail.protection.outlook.com'"
)

REM Change to the source directory 2
cd /d "%sourceDirectory2%" 

REM Create the ZIP file using 7-Zip
"C:\Program Files\7-Zip\7z.exe" a "%destinationDirectory%\%DATE%\App\%zipFile2%" . && (
    echo %DATE%-!hour!:!minute! - HRM_Scripts zip created: %destinationDirectory%\%DATE%\App\%zipFile2% >> "%logfile%"
) || (
    echo %DATE%-!hour!:!minute! - Failed to create HRM_Scripts zip. Possible reasons: permission issues, missing files, etc. >> "%logfile%"   
)

Rem Clear the contents of the text file
echo. > "%bodyfile%"

REM Extract the list of files from the ZIP archive
"C:\Program Files\7-Zip\7z.exe" l "%destinationDirectory%\%DATE%\App\%zipFile1%" > "%destinationDirectory%\%DATE%\App\List_HRM_App_!hour!!minute!.txt"
"C:\Program Files\7-Zip\7z.exe" l "%destinationDirectory%\%DATE%\App\%zipFile2%" > "%destinationDirectory%\%DATE%\App\List_HRM_Scripts_!hour!!minute!.txt"

REM Set the number of days
set "days=2"

REM Calculate the date x days ago
for /f "usebackq tokens=1-3 delims=/" %%a in (`powershell -command "(Get-Date).AddDays(-%days%).ToString('yyyy-MM-dd')"`) do (
    set "targetDate=%%a-%%b-%%c"
)

REM Delete folders older than the target date
powershell.exe -File "E:\DR_Scripts\delfold.ps1
